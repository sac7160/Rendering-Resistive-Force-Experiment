#ifndef _C826_DIO_ADC_H_
#define _C826_DIO_ADC_H_
#include <windows.h>
#include <826api.h>
#include <glm\glm.hpp>

class c826_DIO_ADC {
public:
    //-----------------------------------------------------------------------
    // CONSTRUCTOR & DESTRUCTOR:
    //-----------------------------------------------------------------------
	c826_DIO_ADC();
	c826_DIO_ADC(uint board);
	~c826_DIO_ADC();
	//-----------------------------------------------------------------------
    // METHODS:
    //-----------------------------------------------------------------------
	void setDIOparams(uint idx, uint PWM_ch, uint input1, uint input2, uint counter);
	inline void enableDIOch(bool enable, uint idx) { m_boolPWM[idx] = enable;}
	inline void setAin_ch(uint idx, uint ch) {m_ain_ch[idx] = ch; m_ain_enable[idx]=true;}
	inline void setAout_ch(uint idx, uint ch) {m_aout_ch[idx] = ch; m_aout_enable[idx] = true;}
	int setAout_val(uint idx, double voltage);
	inline int getAin_val(uint idx) { return m_ain_adc[idx];}
	int init(char* ret_string =NULL);
	void getErrorString(int errcode, char* ret_string);
	inline void setPwmFreq(float freq) { m_PWM_freq = freq;}//(float)1000000.0/(float)980.0;}
	int setPwmDutyCycle(int idx, double duty_cycle);
	int setOutPwm(int idx, double value);
	inline void setEncoderCh(uint ch) {m_enable_encoder = true; m_encoder_ch = ch;}
	int PeriodicTimerStart(uint counter, uint period);
	int PeriodicTimerStop(uint counter);
	int PeriodicTimerWait(uint counter, uint *timestamp);
	int PwmGeneratorStart(int idx, uint ontime, uint offtime);
	int PwmGeneratorStop(int idx);
	int zeroEncoderVal();
	int getCounterVal(uint &count);
	int AdcRead();
private:
	void getDIOmask(uint diochan, uint ret[2]);
public:
	//-----------------------------------------------------------------------
    // MEMBERS:
    //-----------------------------------------------------------------------
	uint m_board;
	bool m_boardInit;
	bool m_boolPWM[2];
//	HAND m_h_IOcardThread;
private:
	//// PWM related variables
	float m_PWM_freq;
	uint m_PWM_counterA;	// signal source counter for the DIO channel
	uint m_PWM_counterB;
	int m_826errcode;
	char m_826errString[64];
	uint m_PWM_dioCh_A[3];
	uint m_PWM_diomask_A[3][2];
	uint m_PWM_dioCh_B[3];
	uint m_PWM_diomask_B[3][2];
	//// analog input variables
	bool m_ain_enable[4];
	uint m_ain_ch[4];
	int m_ain_adc[4];
	int m_aout_ch[4];
	bool m_aout_enable[4];		// Feb. 21st 2019
	//// counter variables
	uint m_encoder_ch;
	bool m_enable_encoder;
};

#endif	// _C826_DIO_ADC_H_