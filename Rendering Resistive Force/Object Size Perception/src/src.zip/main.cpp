#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <826api.h>
#include <GL/glut.h>
#include <process.h>
#include "geometry_helper.h"
#include "display_helper.h"
#include "CExp_Size_Perception.h"

#define _TITLE "Object Size Perception Experiment"

void keyboard(unsigned char key, int x, int y);
void display();
void myInit();
void specialKeys(int key, int x, int y);
void idle();

const int WIDTH = 1000;//400;
const int HEIGHT = 600;//400;
int width = WIDTH, height = HEIGHT;

cExp_Size_Perception m_expObjSize;

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_ALPHA);
	glutInitWindowSize(width, height);
	glutCreateWindow(_TITLE);
	glutDisplayFunc(display);
	glutReshapeFunc(DISP_TOOLS::reshapeSubFunc);
	glutKeyboardFunc(keyboard);
	glutSpecialFunc(specialKeys);
	glutIdleFunc(idle);
	glutMouseFunc(DISP_TOOLS::mouseDownSubFunc);//onMouseDown);
	glutMotionFunc(DISP_TOOLS::mouseMoveSubFunc);//onMouseMove);
	myInit();
	glutMainLoop();
	return 0;
}

void keyboard(unsigned char key, int x, int y)
{
	char pTxt[256];
	int key_ret;
	key_ret = m_expObjSize.handleKeyboard(key, pTxt);
	if (key_ret == 100) {
		exit(0);
	}
	else if (key_ret == 102) {	// Error message box
		MessageBox(NULL, pTxt, "Error", MB_OK | MB_ICONERROR);
	}
}

void display()
{
	m_expObjSize.sub_display();
	glFlush();
	glutSwapBuffers();
}
void myInit()
{
	m_expObjSize.init();
}

void specialKeys(int key, int x, int y)
{
	m_expObjSize.handleSpecialKeys(key, x, y);
}

void idle()
{
	Sleep(10);
	glutPostRedisplay();
}