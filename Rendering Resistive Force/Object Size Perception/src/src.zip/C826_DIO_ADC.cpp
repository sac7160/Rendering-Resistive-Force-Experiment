#include "C826_DIO_ADC.h"
#include <stdio.h>
#include <process.h>
#include <math.h>

#define DIO(C)	((uint64)1<<(C))		// convert DIO channel number to uint64 bit mask
#define DIOMASK(N)		{(uint64)(N) & 0xFFFFFF, (uint64)((N) >> 24)}	// convert uint64 bit mask to uint[2] array
#define DIOSTATE(STATES,CHAN)   ((STATES[CHAN / 24] >> (CHAN % 24)) & 1)    // extract dio channel's boolean state from uint[2] array
#define H826(FUNC, ERR_VAL) if((m_826errcode=FUNC) != S826_ERR_OK) {getErrorString(m_826errcode, m_826errString); printf("ERROR:%d, %s\n", m_826errcode, m_826errString); return ERR_VAL;}

c826_DIO_ADC::c826_DIO_ADC() : m_boardInit(false), m_enable_encoder(false), m_encoder_ch(0)
{
	m_board = 0;
	m_PWM_freq = 980.0;//(float)1000000.0/(float)980.0;;
	m_boolPWM[0] = false; m_boolPWM[1] = false;
	/// Default PWM setting
	setDIOparams(0, 5, 4, 3, 5);	// PWM ch(5) , input1(4), input2(3), counter ch(5)
	setDIOparams(1, 12, 11, 10, 4);	// PWM ch(12), input1(11), input2(10), counter ch(4)
	/// Default Analog output setting
	for(int i=0;i<4;i++) {
		m_ain_enable[i] = false;
		m_aout_enable[i] = false;	// Feb 21st 2019
		m_ain_ch[i] = (uint)i;
		m_aout_ch[i] = (uint)i;
	}
}

c826_DIO_ADC::c826_DIO_ADC(uint board) : m_boardInit(false), m_encoder_ch(0)
{
	m_board = board;
	m_PWM_freq = 980.0;//(float)1000000.0/(float)980.0;
	m_boolPWM[0] = false; m_boolPWM[1] = false;
	/// Default PWM setting
	setDIOparams(0, 5, 4, 3, 5);	// PWM ch(5) , input1(4), input2(3), counter ch(5)
	setDIOparams(1, 12, 11, 10, 4);	// PWM ch(12), input1(11), input2(10), counter ch(4)
	/// Default Analog output setting
	for(int i=0;i<4;i++) {
		m_ain_enable[i] = false;
		m_ain_ch[i] = (uint)i;
	}
}

c826_DIO_ADC::~c826_DIO_ADC()
{
}

void c826_DIO_ADC::getErrorString(int errcode, char* ret_string)
{
	switch(errcode) {
    case S826_ERR_OK:    
		break;
    case S826_ERR_BOARD:
		sprintf(ret_string, "Illegal board number");
		break;
    case S826_ERR_VALUE:
		sprintf(ret_string, "Illegal argument");
		break;
    case S826_ERR_NOTREADY:
		sprintf(ret_string, "Device not ready or timeout");
		break;
    case S826_ERR_CANCELLED:
		sprintf(ret_string, "Wait cancelled");
		break;
    case S826_ERR_DRIVER:
		sprintf(ret_string, "Driver call failed");
		break;
    case S826_ERR_MISSEDTRIG:
		sprintf(ret_string, "Missed adc trigger");
		break;
    case S826_ERR_DUPADDR:
		sprintf(ret_string, "Two boards have same number");
		S826_SafeWrenWrite(m_board, 0x02);
		break;
    case S826_ERR_BOARDCLOSED:
		sprintf(ret_string, "Board not open");
		break;
	case S826_ERR_CREATEMUTEX:
		sprintf(ret_string, "Can't create mutex");
		break;
    case S826_ERR_MEMORYMAP:
		sprintf(ret_string, "Can't map board");
		break;
    default:
		sprintf(ret_string, "Unknown error");
		break;
	}
}

void c826_DIO_ADC::getDIOmask(uint diochan, uint ret[2])
{
	ret[0] = (uint64)DIO(diochan) & 0xFFFFFF;
	ret[1] = (uint64)(DIO(diochan) >> 14);
}

void c826_DIO_ADC::setDIOparams(uint idx, uint PWM_ch, uint input1, uint input2, uint counter)
{
	int i;
	if(idx == 0) {
		m_boolPWM[0] = true;
		m_PWM_dioCh_A[0] = PWM_ch;
		m_PWM_dioCh_A[1] = input1;
		m_PWM_dioCh_A[2] = input2;
		m_PWM_counterA = counter;
		for(i=0;i<3;i++) getDIOmask(m_PWM_dioCh_A[i], m_PWM_diomask_A[i]);
	}
	else {
		 m_boolPWM[1] = true;
		m_PWM_dioCh_B[0] = PWM_ch;
		m_PWM_dioCh_B[1] = input1;
		m_PWM_dioCh_B[2] = input2;
		m_PWM_counterB = counter;
		for(i=0;i<3;i++) getDIOmask(m_PWM_dioCh_B[i], m_PWM_diomask_B[i]);
	}
}

int c826_DIO_ADC::setAout_val(uint idx, double voltage)
{
	int ret = 0;
	uint out_val;
	if(m_aout_enable[idx]) {
		if(abs(voltage) <= 10.0) {
			if(voltage >= 0) {
				if(voltage > 5) {
					H826(S826_DacRangeWrite(m_board, m_aout_ch[idx], S826_DAC_SPAN_0_10, 0), -3)
					out_val = (0xFFFF)*(uint)(voltage/10.0);
				}
				else {
					H826(S826_DacRangeWrite(m_board, m_aout_ch[idx], S826_DAC_SPAN_0_5, 0), -3)
					out_val = (0xFFFF)*(uint)(voltage/5.0);
				}
			}
			else {	// negative value
				if(voltage < -5) {
					H826(S826_DacRangeWrite(m_board, m_aout_ch[idx], S826_DAC_SPAN_10_10, 0), -3)
					out_val = (uint)((voltage+10.0)/10.0)*32767;
				}
				else {
					H826(S826_DacRangeWrite(m_board, m_aout_ch[idx], S826_DAC_SPAN_5_5, 0), -3)
					out_val = (uint)((voltage+5.0)/5.0)*32767;
				}
			}
			H826(S826_DacDataWrite(m_board, m_aout_ch[idx], out_val, 0), -2)
		}
		else ret =-2;
	}
	else ret= -1;
	return ret;
}

int c826_DIO_ADC::init(char* ret_string)
{
	int errcode = S826_ERR_OK;
	int boardflags = 0;
	int rc, i;
	uint dio_output_mask[2] = {0, 0};
	uint slotlist =0;
	float init_duty_cycle = 0.23;
	float period = (float)1000000.0/(float)m_PWM_freq;
	uint ontime	= (uint)(init_duty_cycle*period);//m_PWM_freq);
	uint offtime = (uint)((1.0-init_duty_cycle)*period);////m_PWM_freq);
	uint aout = 0;	// 5V source analog output channel for the potentiometer
	uint aout2 = 1;	// 5V source analog output channel for the potentiometer of Omni 2
	boardflags = S826_SystemOpen();
	if(boardflags < 0) {
		Sleep(500);
		return boardflags;
	}
	else {
		m_board = (int)(log((double)boardflags)/log(2.0));
		m_boardInit = true;
		printf("board no: %d\n", m_board);
	}
	rc = S826_SafeWrenWrite(m_board, 0x02);	// write enable
	if(rc !=0) {
		printf("failed to enable wren for watchdog\n");
		return rc;
	}

	//// analog output setting
///// analog output setting: ch=0 & 1
	for(i=0;i<4;i++) {
		setAout_val(i, 5.0);
	}
//	H826(S826_DacRangeWrite(m_board, m_aout_ch[0], S826_DAC_SPAN_0_5, 0), -1)
//	H826(S826_DacRangeWrite(m_board, m_aout_ch[1], S826_DAC_SPAN_0_5, 0), -1)
//	H826(S826_DacRangeWrite(m_board, m_aout_ch[2], S826_DAC_SPAN_0_5, 0), -1)	//2018-03-27
/////// analog output setting- ch:0 & 1;output voltage: 5V
//	H826(S826_DacDataWrite(m_board, m_aout_ch[0], 0xFFFF, 0), -2)
//	H826(S826_DacDataWrite(m_board, m_aout_ch[1], 0xFFFF, 0), -2)
//	H826(S826_DacDataWrite(m_board, m_aout_ch[2], 0xFFFF, 0), -2)			// 2018-03-27
	for(i=0;i<4;i++) {
		if(m_ain_enable[i]) {
			H826(S826_AdcSlotConfigWrite(m_board, m_ain_ch[i], m_ain_ch[i], 50, S826_ADC_GAIN_2), -2)
			slotlist |= 1<<m_ain_ch[i];
		}
	}
	H826(S826_AdcSlotlistWrite(m_board, slotlist, S826_BITWRITE), -3)
	// enable ADC conversion
	H826(S826_AdcEnableWrite(m_board, 1), -4)
//// PWM init
	if(m_boolPWM[0] || m_boolPWM[1]) {
		dio_output_mask[0] = m_PWM_diomask_A[0][0] | m_PWM_diomask_B[0][0];
		dio_output_mask[1] = m_PWM_diomask_A[0][1] | m_PWM_diomask_B[0][1];
	//	printf("DIO output mask %x %x\n", dio_output_mask[0], dio_output_mask[1]);
		H826(S826_DioOutputSourceWrite(m_board, dio_output_mask), -5);	// alternate output source (Enc ch 5 for DIO ch 13)
		H826(S826_DioCapEnablesWrite(m_board, dio_output_mask, dio_output_mask, S826_BITWRITE), -6)
		H826(S826_DioCapRead(m_board, dio_output_mask, 0, 0), -7)
	}
	if(m_boolPWM[0]) {
		/// generate PWM
		PwmGeneratorStart(0, ontime, offtime);
	//	printf("[%x %x][%x %x]\n", m_PWM_diomask_A[1][0], m_PWM_diomask_A[1][1], m_PWM_diomask_A[2][0], m_PWM_diomask_A[2][1]);
		H826(S826_DioOutputWrite(m_board, m_PWM_diomask_A[1], 2), -8)
		H826(S826_DioOutputWrite(m_board, m_PWM_diomask_A[2], 1), -9)	
	}
	if(m_boolPWM[1]) {
		/// generate PWM
		PwmGeneratorStart(1, ontime, offtime);
	//	printf("[%x %x][%x %x]\n", m_PWM_diomask_B[1][0], m_PWM_diomask_B[1][1], m_PWM_diomask_B[2][0], m_PWM_diomask_B[2][1]);
		H826(S826_DioOutputWrite(m_board, m_PWM_diomask_B[1], 2), -8)
		H826(S826_DioOutputWrite(m_board, m_PWM_diomask_B[2], 1), -9)	
	}
	//// Encoder setting
	// halt counter channel if it is running
	if(m_enable_encoder) {
		H826(S826_CounterStateWrite(m_board, m_encoder_ch, 0), -10)
		// Clock mode : External quadrature clock, x4 multiplier
		H826(S826_CounterModeWrite(m_board, m_encoder_ch, 0x00000070), -11)
		// set preload register value for the counter channel to 0;
		//	H826(S826_CounterPreloadWrite(m_board, m_enc_ch, 0, 0), -8)
		// start reading encoder
		H826(S826_CounterStateWrite(m_board, m_encoder_ch, 1), -12)
	}
	return 0;
}
/********************************************************
 * int setPwmDutyCycle(int idx, double duty_cycle)
		
 ********************************************************/
int c826_DIO_ADC::setPwmDutyCycle(int idx, double duty_cycle)
{
	int errcode;
	float period = (float)1000000.0/(float)m_PWM_freq;
	uint ontime	= (uint)(duty_cycle*period);//m_PWM_freq);
	uint offtime = (uint)((1.0-duty_cycle)*period);////m_PWM_freq);
//	m_ontime = (float)ontime/(float)1000000;
//	m_offtime = (float)offtime/(float)1000000;
//	printf("PWM duty cycle %d %d\n", ontime, offtime);
	if(m_boardInit) {
		if(idx == 0)	{
			H826( S826_CounterPreloadWrite(m_board, m_PWM_counterA, 0, offtime), -2)
			H826( S826_CounterPreloadWrite(m_board, m_PWM_counterA, 1, ontime), -3)  // program pwm off-time in microseconds
			H826( S826_CounterStateWrite(m_board, m_PWM_counterA, 1), -4);  // start pwm generator
		}
		else {
			H826( S826_CounterPreloadWrite(m_board, m_PWM_counterB, 0, offtime), -5)
			H826( S826_CounterPreloadWrite(m_board, m_PWM_counterB, 1, ontime), -6)  // program pwm off-time in microseconds
			H826( S826_CounterStateWrite(m_board, m_PWM_counterB, 1), -7);  // start pwm generator
		}
	}
	else return -1;
	return 0;
}
/********************************************************
 * void setOutPwm(int idx, double duty_cycle)
		
 ********************************************************/
int c826_DIO_ADC::setOutPwm(int idx, double value)
{
	double input_val;
	if(m_boardInit) {
		if(value >= 0) {
		//	m_prev_direction = false;
			//if(value > 0.99) input_val = 0.99;//8) input_val = 0.98;
			if(value > 0.99) input_val = 0.99;
			else if(value < 0.10) input_val = 0.10;
			else input_val = value;
			if(idx == 0)	{
				S826_DioOutputWrite(m_board, m_PWM_diomask_A[1], 1);
				S826_DioOutputWrite(m_board, m_PWM_diomask_A[2], 2);
				setPwmDutyCycle(idx, input_val);//value);
			}
			else {
				S826_DioOutputWrite(m_board, m_PWM_diomask_B[1], 1);
				S826_DioOutputWrite(m_board, m_PWM_diomask_B[2], 2);
				setPwmDutyCycle(idx, input_val);//value);
			}
		}
		else {
			//if(value < -0.99) input_val = 0.99;
			if(value < -0.98) input_val = 0.98;
			else if(value > -0.10) input_val = 0.10;
			else input_val = -value;
		//	printf("input_val = %f\n", input_val);
			if(idx == 0) {
				H826(S826_DioOutputWrite(m_board, m_PWM_diomask_A[1], 2), -1)
				H826(S826_DioOutputWrite(m_board, m_PWM_diomask_A[2], 1), -2)
				setPwmDutyCycle(idx, input_val);
			}
			else {
				H826(S826_DioOutputWrite(m_board, m_PWM_diomask_B[1], 2), -3)
				H826(S826_DioOutputWrite(m_board, m_PWM_diomask_B[2], 1), -4)
				setPwmDutyCycle(idx, input_val);
			}
		}
		return 0;
	}
	else return -1;
}
int c826_DIO_ADC::AdcRead()
{
	uint slotlist = 0;
	int errcode, adcbuf[16], i;
	for(i=0;i<4;i++) {
		if(m_ain_enable[i]) slotlist |= (1 << m_ain_ch[i]);
	}
	if(m_boardInit) {
		errcode = S826_AdcRead(m_board, adcbuf, NULL, &slotlist, 1000);
		for(i=0;i<4;i++) {
			if(m_ain_enable[i]) m_ain_adc[i] = adcbuf[m_ain_ch[i]];
		}
		//S826_CounterPreload(m_board, m_encoder_ch, 0, 0);
		return 0;
	}
	else return -1;
}

int c826_DIO_ADC::zeroEncoderVal()
{
	if(m_boardInit && m_enable_encoder) {
		S826_CounterPreload(m_board, m_encoder_ch, 0, 0);
		return 0;
	}
	else return -1;
}

int c826_DIO_ADC::getCounterVal(uint &count)
{
	uint counter;
	if(m_boardInit && m_enable_encoder) {
		S826_CounterRead(m_board, m_encoder_ch, &counter);
		count = counter;
		return 0;
	}
	else return -1;
}

#define PWM_MODE  (S826_CM_K_1MHZ | S826_CM_UD_REVERSE | S826_CM_PX_ZERO | S826_CM_PX_START | S826_CM_BP_BOTH | S826_CM_OM_PRELOAD)
//0x1682020

int c826_DIO_ADC::PwmGeneratorStart(int idx, uint ontime, uint offtime)
{
	uint counter;
	if(m_boardInit) {
		if(idx == 0) counter = m_PWM_counterA;
		else counter = m_PWM_counterB;
		// halt counter channel if it is running
		H826(S826_CounterStateWrite(m_board, counter, 0), -2)
		// clock mode: PWM generator
		H826(S826_CounterModeWrite(m_board, counter, PWM_MODE), -3)
		// don't need counter snapsnots - we're just outputting PWM signal
		H826(S826_CounterSnapshotConfigWrite(m_board, counter, 0, S826_BITWRITE), -4)
		// program PWM off-time in microseconds
		H826(S826_CounterPreloadWrite(m_board, counter, 0, offtime), -5)
		// program PWM on-time in microseconds
		H826(S826_CounterPreloadWrite(m_board, counter, 1, ontime), -6)
		// start PWM generator
		H826(S826_CounterStateWrite(m_board, counter, 1), -7)
		return 0;
	}
	else return -1;
}

int c826_DIO_ADC::PwmGeneratorStop(int idx)
{
	int ret;
	if(m_boardInit) {
		if(idx == 0){
			ret = S826_CounterStateWrite(m_board, m_PWM_counterA, 0);
			S826_DioOutputWrite(m_board, m_PWM_diomask_A[1], 1);
			S826_DioOutputWrite(m_board, m_PWM_diomask_A[2], 1);
			return ret;
		}
		else	{
			ret = S826_CounterStateWrite(m_board, m_PWM_counterB, 0);
			S826_DioOutputWrite(m_board, m_PWM_diomask_B[1], 1);
			S826_DioOutputWrite(m_board, m_PWM_diomask_B[2], 1);
			return ret;
		}
	}
	else return -1;
}

#define TMR_MODE  (S826_CM_K_1MHZ | S826_CM_UD_REVERSE | S826_CM_PX_ZERO | S826_CM_PX_START | S826_CM_OM_NOTZERO)

int c826_DIO_ADC::PeriodicTimerStart(uint counter, uint period)
{
	if(m_boardInit) {
		H826( S826_CounterStateWrite(m_board, counter, 0),							-2)     // halt channel if it's running
		H826( S826_CounterModeWrite(m_board, counter, TMR_MODE),					-3)     // configure counter as periodic timer
		H826( S826_CounterSnapshotConfigWrite(m_board, counter, 4, S826_BITWRITE),	-4)     // capture snapshots at zero counts
		H826( S826_CounterPreloadWrite(m_board, counter, 0, period),				-5)     // timer period in microseconds
		H826( S826_CounterStateWrite(m_board, counter, 1),							-6)     // start timer
		return 0;
	}
	else return -1;
}

int c826_DIO_ADC::PeriodicTimerStop(uint counter)
{
	if(m_boardInit) return S826_CounterStateWrite(m_board, counter, 0);
	else return -1;
}

int c826_DIO_ADC::PeriodicTimerWait(uint counter, uint *timestamp)
{
    uint counts, tstamp, reason;    // counter snapshot
	if(m_boardInit) {
		H826(S826_CounterSnapshotRead(m_board, counter, &counts, &tstamp, &reason, S826_WAIT_INFINITE), -2)
		if (timestamp != NULL) *timestamp = tstamp;
		return 0;
	}
	else return -1;
}

