#ifndef __PHANTOM_HELPER_H__
#define __PHANTOM_HELPER_H__
#include <HD/hd.h>
#include <HDU/hduError.h>
#include <HDU/hduVector.h>
#include "CLink.h"
#include <vector>
#include <string>
#include <glm\glm.hpp>

/*****************************************************************
 * phantom_helper.h
		List of wrap-up functions & variables
					Author Jaeyoung Park (phoenixbird79@gmail.com) 
 *					Last updated on Oct. 10th 2016
 ******************************************************************/


using std::vector;
using std::string;

struct DeviceDisplayState
{
	hduVector3Dd position;
	hduVector3Dd force;
};

namespace PHANTOM_TOOLS {
	enum TYPE {
		OMNI = 0,
		OMNI_GRIPPER,
		PREMIUM_1_0,
		CUSTOM
	};
	typedef struct dev_info {
		int idx;
		int type;
		int num_links;
		int drv_mode;
		glm::vec3 position_offset;
		glm::vec3 tip_position;
		glm::vec3 end_effector_position;
		glm::vec3 pos;
		glm::vec3 joint_angle;
		glm::vec3 gimbal_angle;
		glm::vec3 prev_force;
		glm::mat3x3 rot_mat;
		glm::mat4 T_mat;
		string dev_name;
		float gripper_link_len;	// <= case that the phantom is a gripper type
		HHD hHD;	// device handle
		cLink *plinks[6];
		int sign_mult[6];
		int enc_type[6];	// For a CUSTOM device's encoder reading 
							//-1: dont read in updateDevicePosition(); 0~5: maps to the corresponding phantom encoder
		dev_info() {
			num_links = 0;
			type = TYPE::OMNI;
			hHD = HD_INVALID_HANDLE;
			prev_force = glm::vec3(0, 0, 0);
			for(unsigned int i=0;i<6;i++) plinks[i] = NULL;
		}
	};
	extern vector<dev_info*> m_phantom_info;
	int addDevice(char *dev_name, int type, float gripper_link_len = 0);
	int initDevice(HDSchedulerCallback pCallback, void *pUserData);
	void updateDevicePosition();
	void updateTransformation();
	void setForce(int idx, glm::vec3 force);
	void exitHandler();
	void renderTools();
	void showAxes(int dev_idx, bool show);
	int setCustomLinkInfo(int dev_idx, int num_links, double translate[][3], int *xyz, double *link_len, int *enc_type, double *sign_mult, glm::vec3 color = glm::vec3(0.7, 0.7, 1.0));
	void setEncVal(int dev_idx, int link_idx, double th);
	void setOffset(int idx, glm::vec3 read_position, glm::vec3 nominal_position);
	glm::vec3 getTipPosition(int idx);
	glm::vec3 getEndEffectorPosition(int idx);	
	glm::mat3x3 getEndEffectorOrientation(int idx);
	glm::mat4 getEndEffectorTansformation(int dev_idx);
	glm::vec3 getLinkPosition(int dev_idx, int link_no);
	glm::mat4 getLinkOrientation(int dev_idx, int link_no);
};

HDCallbackCode HDCALLBACK DeviceStateCallback(void *pUserData);

#endif	//__PHANTOM_HELPER_H__

