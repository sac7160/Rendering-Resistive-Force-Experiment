#include "phantom_helper.h"

HDSchedulerHandle gSchedulerCallback = HD_INVALID_HANDLE;

// consts for omni
const double omni_translation[][3] = {{0, 0, -0.16835}, {0, 0.02335, 0}, {0, 0, 0.13335}, {0, -0.13335, 0}, {0, 0, 0}, {0, 0, 0}, {0, 0, 0.052}};//0.0435}};
const int omni_xyz[] = {1, 0, 0, 1, 0, 2};//{-2, -1, -1, 2, -1, 3};
const double omni_link_length[] = {0.02335, 0.13335, 0.13335, 0, 0, 0.0435};

// constants for PHANToM premium 1.0
// origin is at the bottom of the first linkthree links
const double phantom_10_translation[][3] = {{0, 0, 0}, {0, 0.12920, 0}, {0, 0, 0.13942}, {0, -0.11303, 0}};
const int phantom_10_xyz[] = {1, 0, 0};
const double phantom_10_link_length[] = {0.12920, 0.13942, 0.11303};

namespace PHANTOM_TOOLS {
	int m_dev_num = 0;
	vector<dev_info*> m_phantom_info;
	int addDevice(char *dev_name, int type, float gripper_link_len)
	{
		dev_info *pDevInfo = new dev_info();
		pDevInfo->dev_name = string(dev_name);
		pDevInfo->idx = m_dev_num++;
		pDevInfo->type = type;
		if(pDevInfo->type == OMNI_GRIPPER) pDevInfo->gripper_link_len = gripper_link_len;
		m_phantom_info.push_back(pDevInfo);
		return m_dev_num;
	}
/*********************************************************
 * setCustomLinkInfo : Sets link(joint) properties of a device
 **********************************************************/
	int setCustomLinkInfo(int dev_idx, int num_links, double translate[][3], int *xyz, double *link_len, int *enc_type, double *sign_mult, glm::vec3 color)
	{
		int ret = 0, i;
		float iColor[3] = {color[0], color[1], color[2]};
		cLink *pParentLink;
		if(dev_idx >= m_dev_num) return -1;
		dev_info *pDevInfo = m_phantom_info[dev_idx];
		pDevInfo->num_links = num_links;
		for(i=0;i<num_links;i++) {
			if(i==0) pParentLink = NULL;
			else pParentLink = pDevInfo->plinks[i-1];
			pDevInfo->enc_type[i] = enc_type[i];
			pDevInfo->sign_mult[i] = sign_mult[i];
			pDevInfo->plinks[i] = new cLink(iColor, 0.005265);
			pDevInfo->plinks[i]->setAxesSize(0.02, 0.003);
			pDevInfo->plinks[i]->initConfig(pParentLink, glm::vec3(translate[i][0], translate[i][1], translate[i][2]), 
				glm::vec3(translate[i+1][0], translate[i+1][1], translate[i+1][2]), link_len[i], xyz[i], false);
		}
		return ret;
	}
	int initDevice(HDSchedulerCallback pCallback, void *pUserData)
	{
		HHD hHD;
		HDErrorInfo error;
		dev_info *pDevInfo;
		cLink *pParentLink;
		unsigned int i, j;
		float color[3] = {0.5, 0.5, 1.0}, color_phantom[3] = {0.2, 0.2, 0.2};
		char str[128];
		double sign_mult[6] = {-1, -1, -1, 1, -1, -1};
		if(pCallback == NULL) {
			printf("No Phantom callback function is assigned\n");
			exit(0);
		}
		for(i=0;i<m_phantom_info.size();i++)
		{
			pDevInfo = m_phantom_info[i];
			hHD = hdInitDevice(pDevInfo->dev_name.c_str());
			pDevInfo->hHD = hHD;
			if(HD_DEVICE_ERROR(error = hdGetError())) {
				sprintf(str, "Failed to initialize haptic device #%d", pDevInfo->idx);
				hduPrintError(stderr, &error, str);
				fprintf(stderr, "\nPress any key to quit.\n");
				getchar();
				exit(-1);
			}
			printf("Found device %s(%d)\n", hdGetString(HD_DEVICE_MODEL_TYPE), pDevInfo->idx);
			hdEnable(HD_FORCE_OUTPUT);
			hdEnable(HD_MAX_FORCE_CLAMPING);
			////
			if(pDevInfo->type == TYPE::OMNI || pDevInfo->type == TYPE::OMNI_GRIPPER) {
				pDevInfo->num_links = 6;
				for(j=0;j<5;j++) {
					if(j==0) pParentLink = NULL;
					else pParentLink = pDevInfo->plinks[j-1];
					pDevInfo->sign_mult[j] = sign_mult[j];
					pDevInfo->plinks[j] = new cLink(color, 0.01);
					pDevInfo->plinks[j]->setAxesSize(0.02, 0.003);
					pDevInfo->plinks[j]->initConfig(pParentLink, glm::vec3(omni_translation[j][0], omni_translation[j][1], omni_translation[j][2]), 
						glm::vec3(omni_translation[j+1][0], omni_translation[j+1][1], omni_translation[j+1][2]), omni_link_length[j], omni_xyz[j], true);
					if(j>0) pDevInfo->plinks[j]->setParentLink(pDevInfo->plinks[j-1]);
				}
				pDevInfo->plinks[5] = new cLink(color, 0.01);
				pDevInfo->sign_mult[5] = sign_mult[5];
				pDevInfo->plinks[5]->setAxesSize(0.1, 0.003);
				//printf("translation[0] (%f %f %f)\n", pDevInfo->plinks[0]->m_translate[0],  pDevInfo->plinks[0]->m_translate[1],  pDevInfo->plinks[0]->m_translate[2]);
				glm::vec3 link_translate;
				if(pDevInfo->type == TYPE::OMNI) {
					link_translate = glm::vec3(0, 0, 0);
				}
				else  {	// TYPE::OMNI_GRIPPER
					link_translate = glm::vec3(0, 0, pDevInfo->gripper_link_len);//omni_translation[6][0], omni_translation[6][1], omni_translation[6][2]);
				}
				pDevInfo->plinks[5]->initConfig(pDevInfo->plinks[4], glm::vec3(omni_translation[5][0], omni_translation[5][1], omni_translation[5][2]), 
					link_translate, omni_link_length[5], omni_xyz[5], true);
				pDevInfo->plinks[5]->setParentLink(pDevInfo->plinks[4]);
			}
			// PHANToM premium 1.0
			else if (pDevInfo->type == TYPE::PREMIUM_1_0) {
				pDevInfo->num_links;
				for(j=0;j<3;j++) {
					if(j==0) pParentLink = NULL;
					else pParentLink = pDevInfo->plinks[j-1];
					pDevInfo->sign_mult[j] = sign_mult[j];
					pDevInfo->plinks[j] = new cLink(color_phantom, 0.005265);
					pDevInfo->plinks[j]->setAxesSize(0.02, 0.003);
					pDevInfo->plinks[j]->initConfig(pParentLink, glm::vec3(phantom_10_translation[j][0], phantom_10_translation[j][1], phantom_10_translation[j][2]),
						glm::vec3(phantom_10_translation[j+1][0], phantom_10_translation[j+1][1], phantom_10_translation[j+1][2]), phantom_10_link_length[j], phantom_10_xyz[j], color);
				}
			}	// No data for Premium 1.5...
			else if(pDevInfo->type == TYPE::CUSTOM) {
				if(pDevInfo->num_links <=0) {
					hduPrintError(stderr, &error, "Link information not initilized.");
					fprintf(stderr, "\nPress any key to quit,\n");
					getchar();
					exit(-1);
				}
			}
		}
		hdStartScheduler();
		if(HD_DEVICE_ERROR(error = hdGetError())) {
			hduPrintError(stderr, &error, "Failed to start the scheduler");
			fprintf(stderr, "\nPress any key to quit.\n");
			getchar();
			exit(-1);
		}
		gSchedulerCallback = hdScheduleAsynchronous(pCallback, pUserData, HD_DEFAULT_SCHEDULER_PRIORITY);
		if(HD_DEVICE_ERROR(error = hdGetError())) {
			hduPrintError(stderr, &error, "Failed to initialize haptics loop");
			fprintf(stderr, "\nPrint any key to quit.\n");
			getchar();
			exit(-1);
		}
	}
	void updateDevicePosition() {
		dev_info *pDevInfo;
		HDErrorInfo error;
		HHD hHD;
		hduVector3Dd pos[2], joint_angles[2], gimbal_angles[2], contact_force[2];
	//	glm::mat4 T, T_ref, trans;
		unsigned int i, j;
	//	double sign_mult[6] = {-1, -1, -1, 1, -1, -1};
		for(i=0;i<m_phantom_info.size();i++) 
		{
		//	i=0;
			pDevInfo = m_phantom_info[i];
		//	for(j=0;j<3;j++) contact_force[i][j] = pDevInfo->prev_force[j];
			hHD = pDevInfo->hHD;
			hdMakeCurrentDevice(hHD);
		//	HHD hHD = hdGetCurrentDevice();
			hdBeginFrame(hHD);
				hdGetDoublev(HD_CURRENT_POSITION, pos[i]);
				hdGetDoublev(HD_CURRENT_JOINT_ANGLES, joint_angles[i]);
				hdGetDoublev(HD_CURRENT_GIMBAL_ANGLES, gimbal_angles[i]);
			//	hdSetDoublev(HD_CURRENT_FORCE, contact_force);			// force exertion here
			//	printf("force (%f %f %f)\n", contact_force[0], contact_force[1], contact_force[2]);
			//////
		//	hdEndFrame(hHD);
		}
		for(i=0;i<m_phantom_info.size();i++) {
			pDevInfo = m_phantom_info[i];
			hHD = pDevInfo->hHD;
			for(j=0;j<3;j++) contact_force[i][j] = pDevInfo->prev_force[j];
			hdMakeCurrentDevice(hHD);
			hdSetDoublev(HD_CURRENT_FORCE, contact_force[i]);			// force exertion here
			hdEndFrame(hHD);
		}	
		if (HD_DEVICE_ERROR(error = hdGetError()))
		{
			hduPrintError(stderr, &error, "Error during main scheduler callback\n");

			if (hduIsSchedulerError(&error))
			{
				return;
			}        
		}

		for(i=0;i<m_phantom_info.size();i++) {
			pDevInfo = m_phantom_info[i];
	//		T = glm::mat4();// set T to an identity
		//	printf("(%f %f %f)\n", joint_angles[0], joint_angles[1], joint_angles[2]);
			joint_angles[2] -= joint_angles[1];
	//		printf("(%f %f %f)\n", joint_angles[0], joint_angles[1], joint_angles[2]);//, pos[0], pos[1], pos[2]);
	//		printf("device(%d) pos: (%f, %f, %f)\n", pDevInfo->idx, pos[0], pos[1], pos[2]);
			//printf("device(%d) gimbal angle (%f %f %f)\t", i, (float)gimbal_angles[0], (float)gimbal_angles[1], (float)gimbal_angles[2]);
			if(pDevInfo->type == TYPE::OMNI || pDevInfo->type == TYPE::OMNI_GRIPPER) {
				for(j=0;j<3;j++) {
					pDevInfo->plinks[j]->setJointAngle(pDevInfo->sign_mult[j]*joint_angles[i][j]);
					pDevInfo->plinks[j+3]->setJointAngle(pDevInfo->sign_mult[j+3]*gimbal_angles[i][j]);
				}
			}
			else if(pDevInfo->type == TYPE::PREMIUM_1_0) { // PHANToM premium 1.0
				for(j=0;j<3;j++){
					pDevInfo->plinks[j]->setJointAngle(pDevInfo->sign_mult[j]*joint_angles[i][j]);
				}
			}
			else if(pDevInfo->type == TYPE::CUSTOM) {
				for(j=0;j<pDevInfo->num_links;j++) {
					if(pDevInfo->enc_type[j] >= 0) {
						pDevInfo->plinks[j]->setJointAngle(pDevInfo->sign_mult[j]*joint_angles[i][pDevInfo->enc_type[j]]);
					}
				//	printf("%d:%f ", j,pDevInfo->plinks[j]->m_rot_angle);
				}
			//	printf("\n");
			}
		}
	}
	void updateTransformation()
	{
		dev_info *pDevInfo;
		int i, j;
		glm::mat4 T, T_ref, trans;
	//	pDevInfo = m_phantom_info[i];
	//	T = glm::mat4();// set T to an identity
		for(i=0;i<m_phantom_info.size();i++)
		{
			pDevInfo = m_phantom_info[i];
			T = glm::mat4();// set T to an identity
			if(pDevInfo->type == TYPE::OMNI || pDevInfo->type == TYPE::OMNI_GRIPPER) {
				/// update transformation matrices for the links
				for(j=0;j<6;j++) {
					pDevInfo->plinks[j]->updateTransMatrix();
					trans = pDevInfo->plinks[j]->getTransformMatrix();//m_transform_mat;
					T = T*trans;
					if(j==3) {
						T_ref = T*translation_mat(pDevInfo->plinks[j]->m_link_translate);
						pDevInfo->tip_position = glm::vec3(T_ref[3][0], T_ref[3][1], T_ref[3][2]);
					}
				}
				T = T*translation_mat(pDevInfo->plinks[5]->m_link_translate);
			/*	if(pDevInfo->type == TYPE::OMNI_GRIPPER && m_phantom_info.size() == 2) {
					if(i==0) {	// left Omni
						//T = T*rotation_mat(0, -0.5*M_PI)*rotation_mat(1, -0.5*M_PI);
						T=T*rotation_mat(1, -M_PI*0.5)*rotation_mat(0, -M_PI*0.5);
					}
					else {
						T = T*rotation_mat(0, 0.5*M_PI)*rotation_mat(2, -M_PI);
						//T=T*rotation_mat(2, -M_PI*0.5)*rotation_mat(0, M_PI*0.5);
					}
				}	*/
				pDevInfo->end_effector_position = glm::vec3(T[3][0], T[3][1], T[3][2]);
				for(j=0;j<3;j++) {
					pDevInfo->rot_mat[j] = glm::vec3(T[j]);
				}
				pDevInfo->T_mat = T;
			}
			else if(pDevInfo->type == TYPE::PREMIUM_1_0) { // PHANToM premium 1.0
				for(j=0;j<3;j++){
					// update transformation matrices for the links
					pDevInfo->plinks[j]->updateTransMatrix();
					trans = pDevInfo->plinks[j]->getTransformMatrix();	// m_transform_mat
					T = T*trans;
				//	pDevInfo->end_effector_position = glm::vec3(T[3][0]);					
				}
				T = T*translation_mat(pDevInfo->plinks[2]->m_link_translate);
				pDevInfo->end_effector_position = glm::vec3(T[3][0], T[3][1], T[3][2]);
				for(j=0;j<3;j++) pDevInfo->rot_mat[j] = glm::vec3(T[j]);
				pDevInfo->T_mat = T;
			}
			else if(pDevInfo->type == TYPE::CUSTOM) {
				for(j=0;j<pDevInfo->num_links;j++) {
					// update transformation matrices for the links
					pDevInfo->plinks[j]->updateTransMatrix();
					trans = pDevInfo->plinks[j]->getTransformMatrix();	// m_transform_mat
					T = T*trans;
				}
				T = T*translation_mat(pDevInfo->plinks[pDevInfo->num_links-1]->m_link_translate);
				pDevInfo->end_effector_position = glm::vec3(T[3][0], T[3][1], T[3][2]);
				pDevInfo->T_mat = T;
			}
		}
	}

	void showAxes(int dev_idx, bool show)
	{
		dev_info *pDevInfo = m_phantom_info[dev_idx];
		for(int i=0;i<pDevInfo->num_links;i++) {
			pDevInfo->plinks[i]->m_showAxes = show;
		//	num_links
		}
	}

/******************************************************************
 * Manually sets a joint's rotation angle for a custom type device
 ******************************************************************/
	void setEncVal(int dev_idx, int link_idx, double th)
	{
	//	int ret = 0;
		////
		dev_info *pDevInfo = m_phantom_info[dev_idx];
		pDevInfo->plinks[link_idx]->setJointAngle(pDevInfo->sign_mult[link_idx]*th);
	//	return ret;
	}
	void setOffset(int idx, glm::vec3 read_position, glm::vec3 nominal_position)
	{
		dev_info *pDevInfo;
		for(unsigned int i=0;i<m_phantom_info.size();i++) {
			pDevInfo = m_phantom_info[i];
			if(pDevInfo->idx == idx) {
			//	pDevInfo->position_offset = nominal_position - read_position;
				pDevInfo->plinks[0]->setParentTranslationOffset(nominal_position - read_position);//pDevInfo->position_offset);
			}
		}
	}
	void setForce(int idx, glm::vec3 force)
	{
		dev_info *pDevInfo;
		for(unsigned int i=0;i<m_phantom_info.size();i++) {
			pDevInfo = m_phantom_info[i];
			if(pDevInfo->idx == idx) {
				pDevInfo->prev_force = force;
			}
		}
	}
	glm::vec3 getTipPosition(int idx)
	{
		dev_info *pDevInfo;
		for(unsigned int i=0;i<m_phantom_info.size();i++) {
			pDevInfo = m_phantom_info[i];
			if(pDevInfo->idx == idx) {
				return pDevInfo->tip_position;
			}
		}
	}
	glm::mat3x3 getEndEffectorOrientation(int idx){
		dev_info *pDevInfo;
		for(unsigned int i=0;i<m_phantom_info.size();i++) {
			pDevInfo = m_phantom_info[i];
			if(pDevInfo->idx == idx) {
				return pDevInfo->rot_mat;
			}
		}
	}
	glm::mat4 getEndEffectorTansformation(int dev_idx) {
		dev_info *pDevInfo;
		for(unsigned int i=0;i<m_phantom_info.size();i++) {
			pDevInfo = m_phantom_info[i];
			if(pDevInfo->idx == dev_idx) {
				return pDevInfo->T_mat;
			}
		}
	}
	glm::vec3 getEndEffectorPosition(int idx)
	{
		dev_info *pDevInfo;
		for(unsigned int i=0;i<m_phantom_info.size();i++) {
			pDevInfo = m_phantom_info[i];
			if(pDevInfo->idx == idx) {
				return pDevInfo->end_effector_position;
			}
		}
	}
	glm::vec3 getLinkPosition(int dev_idx, int link_no) {
		dev_info *pDevInfo;
		for(unsigned int i=0;i<m_phantom_info.size();i++) {
			pDevInfo = m_phantom_info[i];
			if(pDevInfo->idx == dev_idx) {
				return pDevInfo->plinks[link_no]->getGlobalOriginPosition();
			}
		}
	}
	glm::mat4 getLinkOrientation(int dev_idx, int link_no) {
		dev_info *pDevInfo;
		for(unsigned int i=0;i<m_phantom_info.size();i++) {
			pDevInfo = m_phantom_info[i];
			if(pDevInfo->idx == dev_idx) {
				return pDevInfo->plinks[link_no]->m_g_transform;
			}
		}
	}
	void exitHandler()
	{
		dev_info *pDevInfo;
		hdStopScheduler();
		hdUnschedule(gSchedulerCallback);
		for(unsigned int i=0;i<m_phantom_info.size();i++) {
			pDevInfo = m_phantom_info[i];
			if(pDevInfo->hHD != HD_INVALID_HANDLE) {
				hdDisableDevice(pDevInfo->hHD);
				pDevInfo->hHD = HD_INVALID_HANDLE;
			}
		}
	}
	void renderTools()
	{
		dev_info *pDevInfo;
		for(unsigned int i=0;i<m_phantom_info.size();i++) {
			pDevInfo = m_phantom_info[i];
			if(pDevInfo->plinks[0])
				pDevInfo->plinks[0]->render(true);
		}
	}
};

HDCallbackCode HDCALLBACK DeviceStateCallback(void *pUserData)
{
	DeviceDisplayState *pDisplayState = static_cast<DeviceDisplayState*>(pUserData);
	hdGetDoublev(HD_CURRENT_POSITION, pDisplayState->position);
	hdGetDoublev(HD_CURRENT_FORCE, pDisplayState->force);
	return HD_CALLBACK_DONE;
}
