#include "Serial2.h"
#include <string>
unsigned __stdcall receiverThread(void* arg);

Serial2::Serial2(int port_no, DWORD baudrate)
{
	char portName[24];
	sprintf(portName, "\\\\.\\COM%d", port_no);
#ifdef UNICODE
	wchar_t wtext[20];
	LPWSTR ptr;
	mbstowcs(wtext, portName, strlen(portName)+1);
	ptr = wtext;
#endif
	m_connected = false;
	m_baudrate = baudrate;
	m_nLength = 0;
	m_hSerial 
#ifdef UNICODE
		= CreateFile(ptr,
#else
		=CreateFile(portName,
#endif
					GENERIC_READ | GENERIC_WRITE, 
					0, 
					NULL, 
					OPEN_EXISTING,
					FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OVERLAPPED,
					NULL);
	if(m_hSerial == INVALID_HANDLE_VALUE) {
		if(GetLastError() == ERROR_FILE_NOT_FOUND) {
			printf("ERROR: Handle was not attached. Reason: %s not available.\n", portName);
		}
		else {
			printf("ERROR!!!");
		}
	}
	else {
		// Initializes Serial port configuration
		resetSerial();
		//// initializes overlapped objects for reading and writing
		m_ovl_R.Offset = 0; m_ovl_R.OffsetHigh = 0;
		m_ovl_W.Offset = 0; m_ovl_W.OffsetHigh = 0;
		// Creates events for Overlapped I/O
		m_ovl_R.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
		if(m_ovl_R.hEvent == NULL) {
			CloseHandle(m_ovl_R.hEvent);
			return;
		}
		m_ovl_W.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
		if(m_ovl_W.hEvent == NULL) {
			CloseHandle(m_ovl_W.hEvent);
			return;
		}
		InitializeCriticalSection(&m_cs);
		// Creates the Rx thread
		m_hThread = (HANDLE)_beginthreadex(NULL, 0, receiverThread, (void*)this, 0, NULL);
		EscapeCommFunction(m_hSerial, SETDTR);	// DTR (data-terminal-ready)
	}
}

Serial2::~Serial2()
{
	Close();
}
//#define	InBufSize	50000
//#define	OutBufSize	50000
void Serial2::resetSerial()
{
	DCB dcb = {0};
	DWORD errors;
//	COMMTIMEOUTS CommTimeOuts;
	if(m_hSerial == INVALID_HANDLE_VALUE) return;
	ClearCommError(m_hSerial, &errors, NULL);
	// setting up input/output buffer sizes
	SetupComm(m_hSerial, MAX_SERIAL_BUF, MAX_SERIAL_BUF);
	PurgeComm(m_hSerial, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR);
	//CommTimeOuts.ReadIntervalTimeout = MAXDWORD;
	//CommTimeOuts.ReadTotalTimeoutMultiplier = 0;
	//CommTimeOuts.ReadTotalTimeoutConstant = 0;
	if(!GetCommState(m_hSerial, &dcb)) {
		printf("Failed to get current serial parameters!");
		return;
	}
	else {
		dcb.BaudRate = m_baudrate;
		dcb.ByteSize = 8;
		dcb.StopBits = ONESTOPBIT;
		dcb.Parity = NOPARITY;
		if(!SetCommState(m_hSerial, &dcb)) {
			printf("ALERT: Could not set Serial Port parameters");
		}
		else {
			m_connected = true;
		}
		// Specifies the event of receiving a character placed in the input buffer by a communication device
		// When a character is received, the event is notified and WaitCommEvent function returns a value. 
		SetCommMask(m_hSerial, EV_RXCHAR);
	}
}

bool Serial2::Send(char *pOutBuf, int len)
{
	bool ret = true;
	DWORD ErrorFlags;
	COMSTAT ComStat;
	DWORD BytesWritten;
	ClearCommError(m_hSerial, &ErrorFlags, &ComStat);
	if(!WriteFile(m_hSerial, pOutBuf, len, &BytesWritten, &m_ovl_W)) {
		if(GetLastError() == ERROR_IO_PENDING) {
			if(WaitForSingleObject(m_ovl_W.hEvent, 1000) != WAIT_OBJECT_0)
				ret = false;
			else
				GetOverlappedResult(m_hSerial, &m_ovl_W, &BytesWritten, FALSE);
		}
		else ret = false;
	}
	ClearCommError(m_hSerial, &ErrorFlags, &ComStat);
	return ret;
}

/// retrives Rx data in buffer of the Serial2 object
//
int Serial2::RetrieveRxData(char *pInBuf, int len)
{
	int ret = 0;
	if(len == 0) return -1;
	else if (len > MAX_SERIAL_BUF) return -1;
	if(m_nLength == 0) {
		pInBuf[0] = '\0';
		return 0;
	}
	else if(m_nLength <= len) {
		EnterCriticalSection(&m_cs);
		memcpy(pInBuf, m_InBuf, m_nLength);
		memset(m_InBuf, 0, MAX_SERIAL_BUF*2);
		LeaveCriticalSection(&m_cs);
		ret = m_nLength;
		m_nLength = 0;
		return ret;
	}
	else {
		EnterCriticalSection(&m_cs);
		memcpy(pInBuf, m_InBuf, len);
		memmove(m_InBuf, m_InBuf + len, MAX_SERIAL_BUF*2 - len);
		LeaveCriticalSection(&m_cs);
		m_nLength -= len;
		return len;
	}
	return ret;

}

void Serial2::Close() {
	DWORD dw;
	if(m_connected) {
	m_connected = false;
	dw = WaitForSingleObject(m_hThread, 5000);
	if(dw == WAIT_FAILED) {
		printf("Thread closing error\n");
		exit(-1);
	}
	SetCommMask(m_hSerial, 0x00);
	EscapeCommFunction(m_hSerial, CLRDTR);
	PurgeComm(m_hSerial, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR);
	}
}
unsigned __stdcall receiverThread(void* arg)
{
	Serial2 *pSerial = (Serial2*)arg;
	DWORD	evtMask;
	DWORD	ErrorFlags;
	COMSTAT	ComStat;
	int size, inSize;	// size : max Rx data in bytes; inSize : size of Rx data read so far in bytes
	DWORD Length;		// number of bytes read by ReadFile function
	char buf[MAX_SERIAL_BUF];
	//BOOL 
	while(pSerial->m_connected) {
		evtMask	= 0;
		Length	= 0;
		inSize	= 0;
		memset(buf, 0x00, MAX_SERIAL_BUF);
		if(WaitCommEvent(pSerial->m_hSerial, &evtMask, NULL)) {
			ClearCommError(pSerial->m_hSerial, &ErrorFlags, &ComStat);
			if((evtMask & EV_RXCHAR) && ComStat.cbInQue) {	// some data in the Rx cue
				if(ComStat.cbInQue > MAX_SERIAL_BUF) size = MAX_SERIAL_BUF;
				else size = ComStat.cbInQue;
				do {
					//ClearCommError(pSerial->m_hSerial, &ErrorFlags, &ComStat);
					if(!ReadFile(pSerial->m_hSerial, buf + inSize, size, &Length, &(pSerial->m_ovl_R))) {
						if(GetLastError() == ERROR_IO_PENDING) {	// works like a synchronized I/O
							if(WaitForSingleObject(pSerial->m_ovl_R.hEvent, 1000) != WAIT_OBJECT_0)
								Length = 0;	// data not received
							else
								GetOverlappedResult(pSerial->m_hSerial, &(pSerial->m_ovl_R), &Length, FALSE);
						}
						else Length = 0;
					}
					inSize += Length;
				} while((Length != 0) && (inSize < size));
				//ClearCommError(pSerial->m_hSerial, &ErrorFlags, &ComStat);
				if(pSerial->m_nLength + inSize > MAX_SERIAL_BUF*2)
					inSize = (pSerial->m_nLength + inSize) - MAX_SERIAL_BUF*2;
				EnterCriticalSection(&(pSerial->m_cs));
				memcpy(pSerial->m_InBuf + pSerial->m_nLength, buf, inSize);
				LeaveCriticalSection(&(pSerial->m_cs));
				pSerial->m_nLength += inSize;
			}
		}
	}
	PurgeComm(pSerial->m_hSerial, PURGE_TXABORT | PURGE_RXABORT | PURGE_TXCLEAR | PURGE_RXCLEAR);

	return 0;
}
