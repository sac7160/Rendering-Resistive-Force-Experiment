#ifndef _SERIAL2_H_
#define _SERIAL2_H_

#include <Windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <process.h>

#define MAX_SERIAL_BUF	50000

class Serial2
{
private:
	DWORD m_baudrate;
	HANDLE m_hThread;
public:
	HANDLE m_hSerial;
	int m_nLength;
	bool m_connected;
	OVERLAPPED m_ovl_R;	// OVERLAPPED structure for reading
	OVERLAPPED m_ovl_W;	// OVERLAPPED structure for writing
	char m_InBuf[MAX_SERIAL_BUF*2];
	CRITICAL_SECTION m_cs;

	Serial2(int port_no, DWORD baudrate);
	~Serial2();
	void resetSerial();
	bool Send(char *pOutBuf, int len);
	int RetrieveRxData(char *pInBuf, int len);
	void Close();
};

#endif // #ifndef _SERIAL2_H_
